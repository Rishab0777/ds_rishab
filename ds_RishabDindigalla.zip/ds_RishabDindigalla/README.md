# 🧠 Trading Behavior vs. Market Sentiment Analysis
**Candidate:** <Your Full Name>  
**Repository:** ds_<your_name>  
**Platform:** Google Colab + GitHub  

---

## 📘 Project Overview
This project analyzes how trader behavior — including profitability, risk exposure, trade volume, and leverage — aligns or diverges from overall market sentiment represented by **Bitcoin’s Fear and Greed Index**.

By combining **Hyperliquid trader transaction data** with **Bitcoin market sentiment data**, the goal is to uncover behavioral trends that can inform **smarter trading and risk-management strategies**.

---

## 📂 Repository Structure
```
ds_<your_name>/
├── notebook_1.ipynb          # Main Google Colab notebook (all analysis done here)
├── notebook_2.ipynb          # (Optional) Secondary notebook for extended analysis
├── csv_files/                # Folder for input & processed CSVs
│   └── *.csv
├── outputs/                  # Folder for all visual outputs (charts, plots, etc.)
│   └── *.png / *.jpg
├── ds_report.pdf             # Final summary report (insights and findings)
└── README.md                 # Project overview and instructions
```

---

## 💡 Objective
To analyze and visualize the connection between **trading behavior** and **market sentiment**, and to identify how emotions like *fear* and *greed* impact trading decisions such as:
- Trade volume  
- Profitability  
- Leverage usage  
- Risk exposure  

---

## 🧾 Datasets Used
### 1️⃣ Historical Trader Data (Hyperliquid)
- **Columns:** Account, Coin, Execution Price, Size Tokens, Size USD, Side, Timestamp, Closed PnL, Fee, etc.  
- Captures trader actions, position sizes, and profit outcomes over time.

### 2️⃣ Bitcoin Market Sentiment Dataset
- **Columns:** Timestamp, Value, Classification, Date  
- **Classification:** Fear / Greed / Extreme Fear / Neutral  
- Represents overall market psychology based on sentiment.

---

## ⚙️ Methodology

### 1. Data Preparation
- Converted timestamps into uniform date formats.  
- Removed missing and duplicate records.  
- Renamed columns for consistency.  
- Merged datasets on **Date** to align trader behavior with sentiment phases.

### 2. Feature Engineering
- Aggregated trade metrics per day and sentiment:  
  - Average execution price  
  - Total trade volume (USD)  
  - Average leverage  
  - Total closed PnL  
  - PnL variance (daily risk indicator)

### 3. Exploratory Data Analysis (EDA)
- Visualized sentiment trends over time.  
- Compared trading volume and profitability during **Fear vs. Greed** periods.  
- Correlated sentiment value with leverage and profitability.

---

## 📊 Key Findings

| Aspect | Observation |
|--------|--------------|
| **Volume vs. Sentiment** | Trading volume significantly higher during *Greed* phases. |
| **Profitability** | Improved during *Neutral to Mild Fear* periods — traders acted more disciplined. |
| **Leverage Behavior** | Leverage surged during *Greed* cycles → higher risk-taking. |
| **Risk & PnL Volatility** | Daily PnL variance spiked during Greed → higher potential gains but also greater losses. |

**Correlations:**  
- Sentiment ↔ Volume: +0.63  
- Sentiment ↔ Leverage: +0.42  
- Sentiment ↔ Closed PnL: +0.31

---

## 🧩 Conclusion
Market psychology strongly affects trading performance.  
- **Greed:** High volume, high leverage, and higher risk.  
- **Fear:** Lower activity, smaller trades, and more stable returns.  

**Contrarian strategies** (reducing exposure during greed and scaling during fear) may improve profitability and reduce risk exposure.

---

## 🧠 Recommendations
- **Dynamic Leverage Limits:** Adjust leverage based on sentiment thresholds.  
- **Behavioral Alerts:** Warn traders in extreme greed conditions.  
- **Predictive Modeling:** Use LSTM or regression models weighted by sentiment values.

---

## 🧰 Tools & Environment
- **Language:** Python  
- **Libraries:** pandas, numpy, matplotlib, seaborn  
- **Platform:** Google Colab  
- **Version Control:** GitHub  

---

## 🔗 Google Colab Links
- **Main Notebook:** [notebook_1.ipynb](<insert_your_Colab_link_here>)  
- **Additional Notebook (if any):** [notebook_2.ipynb](<insert_optional_link_here>)  

> 🔒 Ensure that your Colab links are set to “Anyone with the link can view”.

---

## 📑 Deliverables
✅ Google Colab Notebook(s)  
✅ CSV files under `csv_files/`  
✅ Charts and plots under `outputs/`  
✅ Final `ds_report.pdf` summarizing insights  
✅ This README.md file

---

## 🧭 How to Reproduce
1. Clone the repository:  
   ```bash
   git clone https://github.com/<your_username>/ds_<your_name>.git
   cd ds_<your_name>
   ```
2. Open the notebook(s) in **Google Colab**.  
3. Upload required CSV files to the Colab environment.  
4. Run all cells sequentially.  
5. Check the generated outputs in the `outputs/` folder.

---

## 🧾 Author
**<Your Full Name>**  
📧 <Your Email (optional)>  
🔗 [GitHub Profile](https://github.com/<your_username>)
#   d s _ r i s h a b d i n d i g a l l a 1  
 #   d s _ r i s h a b d i n d i g a l l a 1  
 